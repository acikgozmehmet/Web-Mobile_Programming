import { Component, OnInit } from '@angular/core';
import {Content} from '@angular/compiler/src/render3/r3_ast';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {

  constructor() { }

  statusClass: string;
  counter = 0;
  tasks = [];


  Ishidden: boolean = true;

  countDownDate: number ; // = new Date('February 15, 2021 00:00:00').getTime();
  targetDate:any;
  days: any = ' ';
  hours: any = ' ';
  mins: any = ' ';
  secs: any = ' ';




  sendData(val) {
    console.warn(val);
    if (val.taskName.trim() === '') {
      return;
    }

    let isPresent = false;
    for ( let i = 0; i < this.tasks.length; i++)
    {
      if (val.taskName === this.tasks[i].name) {
        isPresent = true;
      }
    }


    const task = {
      name: val.taskName,
      deadline: val.taskDeadline.toString().replace('T', ' '),
      isCompleted: false
    };

    if (!isPresent){
      this.tasks.push(task);
      this.counter++;
      console.log(task);
    }
  }


  showRemainingTime(task)
  {


    if (task.taskName.trim() === '')
    {
      return;
    }



    // console.log(task.taskDeadline.toString());
    const x = setInterval(() => {

      this.countDownDate = new Date(task.taskDeadline.toString()).getTime();

      this.targetDate = new Date(task.taskDeadline.toString()).toDateString();

      const now = new Date().getTime();
      const diff = this.countDownDate - now;
      const day = (1000 * 60 * 60 * 24);
      const hr = 1000 * 60 * 60;
      const min = 1000 * 60;
      const sec = 1000;

      const days = Math.floor(diff / day);
      const hours = Math.floor(diff % day / hr);
      const mins = Math.floor(diff % hr / min);
      const secs = Math.floor(diff % min / sec);

      this.days = days;
      this.hours = hours;
      this.mins = mins;
      this.secs = secs;

      if (diff < 0) {
        this.Ishidden = true;
      }

    });

    this.Ishidden = !this.Ishidden;
  }
  ngOnInit(): void {
  }


  deleteTask(task)
  {
    this.tasks = this.tasks.filter( t => t.name !== task.name);
  }

  crossTask(index)
  {
    this.tasks[index].isCompleted = !this.tasks[index].isCompleted;

  }

  getStatus(index)
  {
    return this.tasks[index].isCompleted === true ? 'line-through' : 'none';
  }




}
